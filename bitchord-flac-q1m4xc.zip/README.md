# bitchord-flac-q1m4xc

BitChord addon for publicly accessible Internet Archive FLAC material.

Endpoints:
- /manifest.json
- /search?q=...
- /stream/<archive_identifier>

Deploy to Vercel, then paste:
https://YOUR-PROJECT.vercel.app/manifest.json

This addon does not bypass DRM, authentication, paywalls, or access controls.
Use only audio you are legally allowed to access.

Suggested GitHub repository: UlulHires/bitchord-flac-q1m4xc
