export default function handler(req, res) {
  res.status(200).json({
    id: "local.example.bitchord.archive-flac",
    name: "Archive FLAC",
    version: "1.0.0",
    resources: ["search", "stream"],
    settings: [
      {
        key: "quality",
        type: "select",
        default: "lossless",
        options: [
          { "label": "Lossless", "value": "lossless" },
          { "label": "High", "value": "high" }
        ]
      }
    ]
  });
}