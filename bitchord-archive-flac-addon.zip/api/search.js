function pick(obj, ...keys) {
  for (const k of keys) if (obj?.[k] != null && obj[k] !== "") return obj[k];
  return "";
}

export default async function handler(req, res) {
  const q = String(req.query.q || "").trim();
  if (!q) return res.status(200).json({ tracks: [] });

  const url =
    "https://archive.org/advancedsearch.php?q=" +
    encodeURIComponent(`mediatype:audio AND (${q})`) +
    "&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=album&fl[]=year&rows=20&page=1&output=json";

  try {
    const r = await fetch(url);
    if (!r.ok) return res.status(502).json({ tracks: [] });
    const data = await r.json();

    const tracks = (data?.response?.docs || []).map((d) => ({
      id: String(d.identifier),
      title: String(pick(d, "title", "identifier")),
      artist: String(pick(d, "creator") || "Internet Archive"),
      album: String(pick(d, "album") || ""),
      duration: 0,
      format: "flac",
      audioQuality: "LOSSLESS"
    }));

    res.status(200).json({ tracks });
  } catch {
    res.status(502).json({ tracks: [] });
  }
}