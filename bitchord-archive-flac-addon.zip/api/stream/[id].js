export default async function handler(req, res) {
  const id = String(req.query.id || "");
  if (!id || !/^[A-Za-z0-9._-]+$/.test(id)) {
    return res.status(404).json({ error: "not found" });
  }

  try {
    const meta = await fetch(
      `https://archive.org/metadata/${encodeURIComponent(id)}`
    );
    if (!meta.ok) return res.status(404).json({ error: "not found" });
    const data = await meta.json();

    const files = Array.isArray(data.files) ? data.files : [];

    // Prefer FLAC. Only advertise lossless when the archive item actually
    // exposes a FLAC file.
    const flac = files.find(f =>
      String(f.name || "").toLowerCase().endsWith(".flac")
    );

    if (!flac) return res.status(404).json({ error: "no flac rendition" });

    const host = data.d1 || data.dir;
    if (!host) return res.status(404).json({ error: "no media host" });

    const mediaUrl =
      `https://archive.org/download/${encodeURIComponent(id)}/` +
      String(flac.name).split("/").map(encodeURIComponent).join("/");

    const sampleRate = Number(flac.sample_rate || 0) || undefined;
    const bitDepth = Number(flac.bitdepth || flac.bits || 0) || undefined;

    const out = {
      url: mediaUrl,
      format: "flac",
      quality: "Lossless",
      codec: "flac",
      container: "flac",
      manifest: "none",
      encrypted: false
    };

    if (sampleRate) out.sampleRate = sampleRate;
    if (bitDepth) out.bitDepth = bitDepth;
    if (Number(flac.size)) out.bitrate = undefined;

    res.status(200).json(out);
  } catch {
    res.status(502).json({ error: "upstream error" });
  }
}