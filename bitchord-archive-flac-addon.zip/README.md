# BitChord Archive FLAC Addon

A small BitChord addon that searches Internet Archive audio items and returns a
direct FLAC URL when the item actually contains a `.flac` file.

## Important

This is a template for publicly accessible Internet Archive material. It does
not bypass DRM, authentication, paywalls, or access controls. Use it only for
material you are legally allowed to access.

## BitChord contract

- `GET /api/manifest.json`
- `GET /api/search?q=...`
- `GET /api/stream/:id`

BitChord normally expects an addon root or manifest URL. For this Vercel layout,
paste the deployment root followed by `/api/manifest.json`, for example:

`https://YOUR-PROJECT.vercel.app/api/manifest.json`

## Deploy on Vercel

1. Put this folder in a GitHub repository.
2. Import the repository into Vercel.
3. Deploy with the default settings.
4. Open `/api/manifest.json` in a browser and verify JSON is returned.
5. In BitChord: Settings -> Sources -> Add an addon.
6. Paste the manifest URL from step 4.
7. Tap Test, then Save.

## Notes

The search endpoint intentionally returns only metadata and does not claim that
every result is FLAC. The stream endpoint checks the Internet Archive item
metadata and returns 404 when no FLAC file is present, allowing BitChord to
fall through to another source.
